CREATE TABLE "access_key_requests" (
	"id" serial PRIMARY KEY NOT NULL,
	"request_id" text NOT NULL,
	"generated_key" text NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"user_name" text,
	"user_email" text,
	"user_phone" text,
	"request_reason" text,
	"admin_messages" text,
	"admin_username" text,
	"case_id" varchar,
	"expires_at" timestamp NOT NULL,
	"approved_at" timestamp,
	"rejected_at" timestamp,
	"key_viewed_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "access_key_requests_request_id_unique" UNIQUE("request_id")
);
--> statement-breakpoint
CREATE TABLE "active_visitors" (
	"id" serial PRIMARY KEY NOT NULL,
	"visitor_id" text NOT NULL,
	"case_id" varchar,
	"current_page" text,
	"page_title" text,
	"referrer" text,
	"device_type" text,
	"browser" text,
	"os" text,
	"screen_resolution" text,
	"ip_address" text,
	"country" text,
	"city" text,
	"pages_viewed" text,
	"page_view_count" integer DEFAULT 1,
	"is_idle" boolean DEFAULT false,
	"idle_since" timestamp,
	"engagement_score" integer DEFAULT 0,
	"has_active_chat" boolean DEFAULT false,
	"chat_started_at" timestamp,
	"proactive_greeting" text,
	"notes" text,
	"session_started_at" timestamp DEFAULT now() NOT NULL,
	"last_heartbeat_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "active_visitors_visitor_id_unique" UNIQUE("visitor_id")
);
--> statement-breakpoint
CREATE TABLE "activity_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar,
	"actor_type" text NOT NULL,
	"actor_id" text,
	"action" text NOT NULL,
	"description" text NOT NULL,
	"metadata" text,
	"ip_address" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "admin_availability" (
	"id" serial PRIMARY KEY NOT NULL,
	"admin_username" text NOT NULL,
	"status" text DEFAULT 'offline' NOT NULL,
	"status_message" text,
	"auto_away_after" integer DEFAULT 300,
	"sound_enabled" boolean DEFAULT true,
	"desktop_notifications" boolean DEFAULT true,
	"email_notifications" boolean DEFAULT false,
	"last_activity_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "admin_availability_admin_username_unique" UNIQUE("admin_username")
);
--> statement-breakpoint
CREATE TABLE "admin_messages" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"category" text DEFAULT 'processing' NOT NULL,
	"title" text NOT NULL,
	"body" text NOT NULL,
	"is_read" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "admin_sessions" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"admin_username" text NOT NULL,
	"token" text NOT NULL,
	"ip_address" text,
	"user_agent" text,
	"location" text,
	"is_active" boolean DEFAULT true,
	"last_activity_at" timestamp DEFAULT now() NOT NULL,
	"expires_at" timestamp NOT NULL,
	"revoked_at" timestamp,
	"revoked_reason" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "admin_sessions_token_unique" UNIQUE("token")
);
--> statement-breakpoint
CREATE TABLE "admin_two_factor" (
	"id" serial PRIMARY KEY NOT NULL,
	"admin_username" text NOT NULL,
	"secret" text NOT NULL,
	"backup_codes" text,
	"is_enabled" boolean DEFAULT false,
	"last_verified_at" timestamp,
	"enabled_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "admin_two_factor_admin_username_unique" UNIQUE("admin_username")
);
--> statement-breakpoint
CREATE TABLE "admin_users" (
	"id" serial PRIMARY KEY NOT NULL,
	"username" text NOT NULL,
	"password_hash" text NOT NULL,
	"role" text DEFAULT 'agent' NOT NULL,
	"display_name" text,
	"email" text,
	"is_active" boolean DEFAULT true,
	"two_factor_enabled" boolean DEFAULT false,
	"two_factor_secret" text,
	"last_login_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "admin_users_username_unique" UNIQUE("username")
);
--> statement-breakpoint
CREATE TABLE "audit_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"admin_username" text NOT NULL,
	"action" text NOT NULL,
	"target_type" text,
	"target_id" text,
	"previous_value" text,
	"new_value" text,
	"ip_address" text,
	"user_agent" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "auto_greetings" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"message" text NOT NULL,
	"trigger_type" text NOT NULL,
	"trigger_page" text,
	"trigger_delay" integer DEFAULT 0,
	"target_new_visitors" boolean DEFAULT true,
	"target_returning_visitors" boolean DEFAULT true,
	"target_logged_in" boolean DEFAULT true,
	"target_anonymous" boolean DEFAULT true,
	"is_active" boolean DEFAULT true,
	"priority" integer DEFAULT 0,
	"show_once_per_session" boolean DEFAULT true,
	"created_by" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "blocked_visitors" (
	"id" serial PRIMARY KEY NOT NULL,
	"visitor_id" text,
	"ip_address" text,
	"reason" text,
	"blocked_by" text,
	"blocked_at" timestamp DEFAULT now() NOT NULL,
	"expires_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "bot_profiles" (
	"id" serial PRIMARY KEY NOT NULL,
	"handle" text NOT NULL,
	"display_name" text NOT NULL,
	"avatar_initials" text NOT NULL,
	"department_id" integer,
	"case_stage" text DEFAULT 'active',
	"personality" text,
	"joined_date" timestamp DEFAULT now() NOT NULL,
	"post_count" text DEFAULT '0',
	"reputation" text DEFAULT '0',
	"badge_level" text DEFAULT 'member',
	"is_active" boolean DEFAULT true,
	"last_post_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "bot_profiles_handle_unique" UNIQUE("handle")
);
--> statement-breakpoint
CREATE TABLE "bot_scheduled_posts" (
	"id" serial PRIMARY KEY NOT NULL,
	"bot_id" integer,
	"thread_id" integer,
	"post_type" text DEFAULT 'reply' NOT NULL,
	"content" text NOT NULL,
	"scheduled_for" timestamp NOT NULL,
	"status" text DEFAULT 'pending',
	"posted_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "case_emails" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"to_email" text NOT NULL,
	"subject" text NOT NULL,
	"body" text NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"error_message" text,
	"sent_by" text,
	"sent_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "case_letters" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"letter_file" text,
	"letter_file_name" text,
	"letter_file_type" text,
	"headline" text DEFAULT 'Withdrawal Protocol Selection',
	"introduction" text,
	"body_content" text,
	"footer_note" text,
	"compliance_reference" text,
	"option_a_title" text DEFAULT 'Accelerated Release',
	"option_a_description" text,
	"option_a_amount" text,
	"option_a_frequency" text,
	"option_a_batches" text,
	"option_a_key_cost" text,
	"option_a_total_requirement" text,
	"option_a_total_amount" text,
	"option_a_fileloco_id" text,
	"option_b_title" text DEFAULT 'Standard Release',
	"option_b_description" text,
	"option_b_amount" text,
	"option_b_frequency" text,
	"option_b_batches" text,
	"option_b_key_cost" text,
	"option_b_total_requirement" text,
	"option_b_total_amount" text,
	"option_b_fileloco_id" text,
	"phrase_key_requirements" text,
	"compliance_notice" text,
	"scheduled_for" timestamp,
	"sent_at" timestamp,
	"expires_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "case_notes" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"admin_username" text NOT NULL,
	"content" text NOT NULL,
	"is_pinned" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "case_submissions" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"selected_option" text NOT NULL,
	"notes" text,
	"user_name" text,
	"user_email" text,
	"withdrawal_amount" text,
	"withdrawal_batches" text,
	"submitted_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "cases" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"access_code" text NOT NULL,
	"status" text DEFAULT 'created' NOT NULL,
	"user_name" text,
	"user_email" text,
	"user_mobile" text,
	"vip_status" text,
	"username" text,
	"withdrawal_amount" text,
	"withdrawal_batches" text,
	"physilocal0" text,
	"deposit_address" text,
	"profile_redirect_url" text,
	"has_requirements" boolean DEFAULT false,
	"letter_sent" boolean DEFAULT false,
	"landing_page" text DEFAULT 'dashboard',
	"priority" text DEFAULT 'medium',
	"assigned_to" text,
	"tags" text,
	"internal_notes" text,
	"last_login_ip" text,
	"last_login_location" text,
	"last_login_at" timestamp,
	"completion_percentage" text DEFAULT '0',
	"show_withdrawal_progress" boolean DEFAULT false,
	"withdrawal_stage" text DEFAULT '1',
	"activity_deposit_amount" text,
	"phrase_key_deposit_amount" text,
	"phrase_key_merge_deposit" text,
	"activity_wallet_requirement" text,
	"phrase_key_certificate_sent" boolean DEFAULT false,
	"submission_url" text,
	"user_pin" text,
	"is_disabled" boolean DEFAULT false,
	"department_id" integer,
	"current_stage_id" integer,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "cases_access_code_unique" UNIQUE("access_code")
);
--> statement-breakpoint
CREATE TABLE "chat_messages" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"sender" text NOT NULL,
	"message" text NOT NULL,
	"is_read" text DEFAULT 'false',
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "chat_satisfaction_ratings" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"visitor_id" text,
	"rating" integer NOT NULL,
	"feedback" text,
	"agent_helpfulness" integer,
	"response_speed" integer,
	"issue_resolved" boolean,
	"admin_username" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "chat_statistics" (
	"id" serial PRIMARY KEY NOT NULL,
	"date" timestamp NOT NULL,
	"total_visitors" integer DEFAULT 0,
	"unique_visitors" integer DEFAULT 0,
	"total_chats" integer DEFAULT 0,
	"proactive_chats" integer DEFAULT 0,
	"avg_response_time" integer,
	"avg_chat_duration" integer,
	"avg_rating" text,
	"total_ratings" integer DEFAULT 0,
	"agent_metrics" text,
	"peak_hours" text,
	"top_pages" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "chat_tags" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"color" text DEFAULT '#004182',
	"description" text,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "chat_tags_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "chat_templates" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"content" text NOT NULL,
	"category" text DEFAULT 'general',
	"shortcut" text,
	"is_active" boolean DEFAULT true,
	"usage_count" text DEFAULT '0',
	"created_by" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "community_moderation_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"admin_username" text NOT NULL,
	"action" text NOT NULL,
	"target_type" text NOT NULL,
	"target_id" text NOT NULL,
	"reason" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "community_participants" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar,
	"anonymous_handle" text NOT NULL,
	"department_id" integer,
	"joined_at" timestamp DEFAULT now() NOT NULL,
	"post_count" text DEFAULT '0',
	"reputation" text DEFAULT '0',
	"badge_level" text DEFAULT 'newcomer',
	CONSTRAINT "community_participants_anonymous_handle_unique" UNIQUE("anonymous_handle")
);
--> statement-breakpoint
CREATE TABLE "community_posts" (
	"id" serial PRIMARY KEY NOT NULL,
	"thread_id" integer,
	"content" text NOT NULL,
	"author_type" text DEFAULT 'bot' NOT NULL,
	"author_handle" text NOT NULL,
	"author_bot_id" integer,
	"is_hidden" boolean DEFAULT false,
	"like_count" text DEFAULT '0',
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "community_reactions" (
	"id" serial PRIMARY KEY NOT NULL,
	"post_id" integer,
	"participant_id" integer,
	"reaction_type" text DEFAULT 'like' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "community_threads" (
	"id" serial PRIMARY KEY NOT NULL,
	"department_id" integer,
	"title" text NOT NULL,
	"content" text NOT NULL,
	"author_type" text DEFAULT 'bot' NOT NULL,
	"author_handle" text NOT NULL,
	"author_bot_id" integer,
	"is_pinned" boolean DEFAULT false,
	"is_locked" boolean DEFAULT false,
	"view_count" text DEFAULT '0',
	"reply_count" text DEFAULT '0',
	"last_activity_at" timestamp DEFAULT now() NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "contact_submissions" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"email" text NOT NULL,
	"subject" text,
	"message" text NOT NULL,
	"status" text DEFAULT 'new',
	"admin_notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conversation_notes" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"admin_username" text NOT NULL,
	"content" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "conversation_tags" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"tag_id" integer NOT NULL,
	"added_by" text,
	"added_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "department_stages" (
	"id" serial PRIMARY KEY NOT NULL,
	"department_id" integer,
	"name" text NOT NULL,
	"description" text,
	"stage_order" text DEFAULT '1' NOT NULL,
	"sla_days" text,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "departments" (
	"id" serial PRIMARY KEY NOT NULL,
	"key" text NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"icon" text,
	"color" text DEFAULT '#004182',
	"display_order" text DEFAULT '0',
	"is_active" boolean DEFAULT true,
	"workflow_config" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "departments_key_unique" UNIQUE("key")
);
--> statement-breakpoint
CREATE TABLE "deposit_receipts" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"submission_id" serial NOT NULL,
	"image_data" text,
	"file_name" text,
	"notes" text,
	"status" text DEFAULT 'pending',
	"admin_notes" text,
	"uploaded_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "document_requests" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"document_type" text NOT NULL,
	"description" text,
	"status" text DEFAULT 'pending',
	"submitted_file_data" text,
	"submitted_file_name" text,
	"admin_notes" text,
	"deadline" timestamp,
	"submitted_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "earned_badges" (
	"id" serial PRIMARY KEY NOT NULL,
	"participant_id" integer,
	"badge_id" integer,
	"earned_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "faq_items" (
	"id" serial PRIMARY KEY NOT NULL,
	"question" text NOT NULL,
	"answer" text NOT NULL,
	"category" text DEFAULT 'general',
	"display_order" text DEFAULT '0',
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "help_articles" (
	"id" serial PRIMARY KEY NOT NULL,
	"title" text NOT NULL,
	"content" text NOT NULL,
	"category" text DEFAULT 'general',
	"display_order" text DEFAULT '0',
	"is_published" boolean DEFAULT true,
	"view_count" text DEFAULT '0',
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "message_templates" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"category" text DEFAULT 'general',
	"content" text NOT NULL,
	"is_active" boolean DEFAULT true,
	"usage_count" text DEFAULT '0',
	"created_by" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "newsletter_subscribers" (
	"id" serial PRIMARY KEY NOT NULL,
	"email" text NOT NULL,
	"is_active" boolean DEFAULT true,
	"subscribed_at" timestamp DEFAULT now() NOT NULL,
	"unsubscribed_at" timestamp,
	CONSTRAINT "newsletter_subscribers_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"id" serial PRIMARY KEY NOT NULL,
	"recipient_type" text NOT NULL,
	"recipient_id" text,
	"type" text NOT NULL,
	"title" text NOT NULL,
	"body" text,
	"link" text,
	"is_read" boolean DEFAULT false,
	"metadata" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "offline_messages" (
	"id" serial PRIMARY KEY NOT NULL,
	"visitor_id" text,
	"case_id" varchar,
	"name" text,
	"email" text,
	"phone" text,
	"subject" text,
	"message" text NOT NULL,
	"status" text DEFAULT 'new',
	"replied_by" text,
	"replied_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "pending_bot_responses" (
	"id" serial PRIMARY KEY NOT NULL,
	"thread_id" integer,
	"trigger_post_id" integer,
	"bot_id" integer,
	"content" text NOT NULL,
	"scheduled_for" timestamp NOT NULL,
	"status" text DEFAULT 'pending',
	"delivered_at" timestamp,
	"result_post_id" integer,
	"error_message" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "proactive_chats" (
	"id" serial PRIMARY KEY NOT NULL,
	"visitor_id" text NOT NULL,
	"case_id" varchar,
	"admin_username" text NOT NULL,
	"initial_message" text NOT NULL,
	"status" text DEFAULT 'sent',
	"opened_at" timestamp,
	"replied_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "scam_alerts" (
	"id" serial PRIMARY KEY NOT NULL,
	"title" text NOT NULL,
	"description" text,
	"severity" text DEFAULT 'medium',
	"platform_name" text,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "scheduled_messages" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar,
	"message_type" text NOT NULL,
	"category" text,
	"title" text,
	"content" text NOT NULL,
	"scheduled_for" timestamp NOT NULL,
	"status" text DEFAULT 'pending',
	"sent_at" timestamp,
	"created_by" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "site_statistics" (
	"id" serial PRIMARY KEY NOT NULL,
	"key" text NOT NULL,
	"value" text NOT NULL,
	"label" text NOT NULL,
	"icon" text,
	"display_order" text DEFAULT '0',
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "site_statistics_key_unique" UNIQUE("key")
);
--> statement-breakpoint
CREATE TABLE "testimonials" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"location" text,
	"avatar" text,
	"rating" text DEFAULT '5' NOT NULL,
	"content" text NOT NULL,
	"is_approved" boolean DEFAULT false,
	"is_featured" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "translations" (
	"id" serial PRIMARY KEY NOT NULL,
	"key" text NOT NULL,
	"locale" text NOT NULL,
	"value" text NOT NULL,
	"context" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "typing_indicators" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"sender" text NOT NULL,
	"sender_name" text,
	"is_typing" boolean DEFAULT true,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_badges" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"icon" text,
	"color" text DEFAULT '#004182',
	"requirement" text,
	"display_order" text DEFAULT '0',
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "user_badges_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "user_documents" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"file_name" text NOT NULL,
	"file_type" text NOT NULL,
	"file_data" text,
	"file_size" text,
	"category" text DEFAULT 'general',
	"description" text,
	"status" text DEFAULT 'uploaded',
	"admin_notes" text,
	"uploaded_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_feedback" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"rating" text NOT NULL,
	"comment" text,
	"feedback_type" text DEFAULT 'support',
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_sessions" (
	"id" serial PRIMARY KEY NOT NULL,
	"case_id" varchar NOT NULL,
	"session_token" text NOT NULL,
	"ip_address" text,
	"user_agent" text,
	"location" text,
	"is_active" boolean DEFAULT true,
	"last_activity_at" timestamp DEFAULT now() NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"expires_at" timestamp,
	CONSTRAINT "user_sessions_session_token_unique" UNIQUE("session_token")
);
--> statement-breakpoint
CREATE TABLE "visitor_history" (
	"id" serial PRIMARY KEY NOT NULL,
	"visitor_id" text NOT NULL,
	"case_id" varchar,
	"pages_viewed" text,
	"page_view_count" integer DEFAULT 0,
	"session_duration" integer,
	"device_type" text,
	"browser" text,
	"country" text,
	"city" text,
	"had_chat" boolean DEFAULT false,
	"chat_id" integer,
	"session_started_at" timestamp NOT NULL,
	"session_ended_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "working_hours" (
	"id" serial PRIMARY KEY NOT NULL,
	"day_of_week" integer NOT NULL,
	"start_time" text,
	"end_time" text,
	"is_enabled" boolean DEFAULT true,
	"timezone" text DEFAULT 'UTC'
);
--> statement-breakpoint
ALTER TABLE "access_key_requests" ADD CONSTRAINT "access_key_requests_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "active_visitors" ADD CONSTRAINT "active_visitors_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "activity_logs" ADD CONSTRAINT "activity_logs_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "admin_messages" ADD CONSTRAINT "admin_messages_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_profiles" ADD CONSTRAINT "bot_profiles_department_id_departments_id_fk" FOREIGN KEY ("department_id") REFERENCES "public"."departments"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_scheduled_posts" ADD CONSTRAINT "bot_scheduled_posts_bot_id_bot_profiles_id_fk" FOREIGN KEY ("bot_id") REFERENCES "public"."bot_profiles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_scheduled_posts" ADD CONSTRAINT "bot_scheduled_posts_thread_id_community_threads_id_fk" FOREIGN KEY ("thread_id") REFERENCES "public"."community_threads"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "case_emails" ADD CONSTRAINT "case_emails_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "case_letters" ADD CONSTRAINT "case_letters_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "case_notes" ADD CONSTRAINT "case_notes_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "case_submissions" ADD CONSTRAINT "case_submissions_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "chat_messages" ADD CONSTRAINT "chat_messages_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "chat_satisfaction_ratings" ADD CONSTRAINT "chat_satisfaction_ratings_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "community_participants" ADD CONSTRAINT "community_participants_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "community_participants" ADD CONSTRAINT "community_participants_department_id_departments_id_fk" FOREIGN KEY ("department_id") REFERENCES "public"."departments"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "community_posts" ADD CONSTRAINT "community_posts_thread_id_community_threads_id_fk" FOREIGN KEY ("thread_id") REFERENCES "public"."community_threads"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "community_reactions" ADD CONSTRAINT "community_reactions_post_id_community_posts_id_fk" FOREIGN KEY ("post_id") REFERENCES "public"."community_posts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "community_reactions" ADD CONSTRAINT "community_reactions_participant_id_community_participants_id_fk" FOREIGN KEY ("participant_id") REFERENCES "public"."community_participants"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "community_threads" ADD CONSTRAINT "community_threads_department_id_departments_id_fk" FOREIGN KEY ("department_id") REFERENCES "public"."departments"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "conversation_notes" ADD CONSTRAINT "conversation_notes_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "conversation_tags" ADD CONSTRAINT "conversation_tags_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "conversation_tags" ADD CONSTRAINT "conversation_tags_tag_id_chat_tags_id_fk" FOREIGN KEY ("tag_id") REFERENCES "public"."chat_tags"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "department_stages" ADD CONSTRAINT "department_stages_department_id_departments_id_fk" FOREIGN KEY ("department_id") REFERENCES "public"."departments"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "deposit_receipts" ADD CONSTRAINT "deposit_receipts_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "document_requests" ADD CONSTRAINT "document_requests_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "earned_badges" ADD CONSTRAINT "earned_badges_participant_id_community_participants_id_fk" FOREIGN KEY ("participant_id") REFERENCES "public"."community_participants"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "earned_badges" ADD CONSTRAINT "earned_badges_badge_id_user_badges_id_fk" FOREIGN KEY ("badge_id") REFERENCES "public"."user_badges"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "offline_messages" ADD CONSTRAINT "offline_messages_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pending_bot_responses" ADD CONSTRAINT "pending_bot_responses_thread_id_community_threads_id_fk" FOREIGN KEY ("thread_id") REFERENCES "public"."community_threads"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pending_bot_responses" ADD CONSTRAINT "pending_bot_responses_trigger_post_id_community_posts_id_fk" FOREIGN KEY ("trigger_post_id") REFERENCES "public"."community_posts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pending_bot_responses" ADD CONSTRAINT "pending_bot_responses_bot_id_bot_profiles_id_fk" FOREIGN KEY ("bot_id") REFERENCES "public"."bot_profiles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "proactive_chats" ADD CONSTRAINT "proactive_chats_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "scheduled_messages" ADD CONSTRAINT "scheduled_messages_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "typing_indicators" ADD CONSTRAINT "typing_indicators_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_documents" ADD CONSTRAINT "user_documents_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_feedback" ADD CONSTRAINT "user_feedback_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_sessions" ADD CONSTRAINT "user_sessions_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "visitor_history" ADD CONSTRAINT "visitor_history_case_id_cases_id_fk" FOREIGN KEY ("case_id") REFERENCES "public"."cases"("id") ON DELETE no action ON UPDATE no action;