import{c as h,r,R as B,u as T,d as S,j as f,a as L,P as _,Q as z,f as C}from"./index-CGttEab3.js";import{u as U}from"./index-Bb27y2qE.js";/**
 * @license lucide-react v0.545.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=[["path",{d:"M3 3v16a2 2 0 0 0 2 2h16",key:"c24i48"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]],re=h("chart-column",q);/**
 * @license lucide-react v0.545.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",key:"1u773s"}],["path",{d:"M12 17h.01",key:"p32p05"}]],ce=h("circle-question-mark",A);/**
 * @license lucide-react v0.545.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],se=h("circle",H);/**
 * @license lucide-react v0.545.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]],ae=h("layout-dashboard",D);/**
 * @license lucide-react v0.545.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F=[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]],ie=h("map-pin",F);/**
 * @license lucide-react v0.545.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=[["path",{d:"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",key:"1i5ecw"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],de=h("settings",O);function Q(e,n,{checkForDefaultPrevented:t=!0}={}){return function(o){if(e?.(o),t===!1||!o.defaultPrevented)return n?.(o)}}var V=B[" useInsertionEffect ".trim().toString()]||T;function W({prop:e,defaultProp:n,onChange:t=()=>{},caller:a}){const[o,i,u]=X({defaultProp:n,onChange:t}),c=e!==void 0,l=c?e:o;{const s=r.useRef(e!==void 0);r.useEffect(()=>{const d=s.current;d!==c&&console.warn(`${a} is changing from ${d?"controlled":"uncontrolled"} to ${c?"controlled":"uncontrolled"}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`),s.current=c},[c,a])}const p=r.useCallback(s=>{if(c){const d=G(s)?s(e):s;d!==e&&u.current?.(d)}else i(s)},[c,e,i,u]);return[l,p]}function X({defaultProp:e,onChange:n}){const[t,a]=r.useState(e),o=r.useRef(t),i=r.useRef(n);return V(()=>{i.current=n},[n]),r.useEffect(()=>{o.current!==t&&(i.current?.(t),o.current=t)},[t,o]),[t,a,i]}function G(e){return typeof e=="function"}var v="Switch",[J]=L(v),[K,Y]=J(v),R=r.forwardRef((e,n)=>{const{__scopeSwitch:t,name:a,checked:o,defaultChecked:i,required:u,disabled:c,value:l="on",onCheckedChange:p,form:s,...d}=e,[m,y]=r.useState(null),w=S(n,b=>y(b)),g=r.useRef(!1),x=m?s||!!m.closest("form"):!0,[k,I]=W({prop:o,defaultProp:i??!1,onChange:p,caller:v});return f.jsxs(K,{scope:t,checked:k,disabled:c,children:[f.jsx(_.button,{type:"button",role:"switch","aria-checked":k,"aria-required":u,"data-state":M(k),"data-disabled":c?"":void 0,disabled:c,value:l,...d,ref:w,onClick:Q(e.onClick,b=>{I($=>!$),x&&(g.current=b.isPropagationStopped(),g.current||b.stopPropagation())})}),x&&f.jsx(N,{control:m,bubbles:!g.current,name:a,value:l,checked:k,required:u,disabled:c,form:s,style:{transform:"translateX(-100%)"}})]})});R.displayName=v;var E="SwitchThumb",P=r.forwardRef((e,n)=>{const{__scopeSwitch:t,...a}=e,o=Y(E,t);return f.jsx(_.span,{"data-state":M(o.checked),"data-disabled":o.disabled?"":void 0,...a,ref:n})});P.displayName=E;var Z="SwitchBubbleInput",N=r.forwardRef(({__scopeSwitch:e,control:n,checked:t,bubbles:a=!0,...o},i)=>{const u=r.useRef(null),c=S(u,i),l=U(t),p=z(n);return r.useEffect(()=>{const s=u.current;if(!s)return;const d=window.HTMLInputElement.prototype,y=Object.getOwnPropertyDescriptor(d,"checked").set;if(l!==t&&y){const w=new Event("click",{bubbles:a});y.call(s,t),s.dispatchEvent(w)}},[l,t,a]),f.jsx("input",{type:"checkbox","aria-hidden":!0,defaultChecked:t,...o,tabIndex:-1,ref:c,style:{...o.style,...p,position:"absolute",pointerEvents:"none",opacity:0,margin:0}})});N.displayName=Z;function M(e){return e?"checked":"unchecked"}var j=R,ee=P;const te=r.forwardRef(({className:e,...n},t)=>f.jsx(j,{className:C("peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input",e),...n,ref:t,children:f.jsx(ee,{className:C("pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0")})}));te.displayName=j.displayName;export{se as C,ae as L,ie as M,te as S,ce as a,re as b,de as c};
