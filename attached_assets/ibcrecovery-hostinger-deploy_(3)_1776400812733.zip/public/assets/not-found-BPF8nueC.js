import{h as o,r as e}from"./index-CGttEab3.js";function r(){const[,t]=o();return e.useEffect(()=>{t("/")},[t]),null}export{r as default};
